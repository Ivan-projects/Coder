from tkinter import *
from PIL import Image, ImageTk

class App:


    def __init__(self):
        self.root = Tk()
        self.root.geometry(f"800x700")
        self.root.title("Coder")
        self.frame = Frame(self.root)
        self.frame.grid()





        self.btn_start = Button(self.frame, text="Start", command = self.get_entry)
        self.btn_clear = Button(self.frame, text="Clear", command = self.get_clear)
        self.name = Entry(self.frame)
        self.name.grid(row=1, column=1)
        self.btn_start.grid(row=1, column = 2)
        self.btn_clear.grid(row = 1, column = 3)





        self.canvas = Canvas(self.root, height=1010, width=1200)
        self.image = Image.open(f"Photos/8.png")
        self.photo = ImageTk.PhotoImage(self.image)
        self.image = self.canvas.create_image(0, 0, anchor='nw', image=self.photo)
        self.canvas.grid(row=2, column=1)





        self.root.mainloop()

    def get_entry(self):
        value = self.name.get()
        a = int(value)
        self.image = Image.open(f"Photos/{a}.png")
        self.photo = ImageTk.PhotoImage(self.image)
        self.c_image = self.canvas.create_image(0, 0, anchor='nw', image=self.photo)
        self.canvas.grid(row=2, column=1)




    def get_clear(self):
        self.image = Image.open("Photos/8.png")
        self.photo = ImageTk.PhotoImage(self.image)
        self.c_image = self.canvas.create_image(0, 0, anchor='nw', image=self.photo)
        self.canvas.grid(row=2, column=1)





app = App()