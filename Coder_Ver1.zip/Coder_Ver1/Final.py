
import tkinter as tk


X = [0] * 8
Y = [0] * 3

def Zn(a):
    for i in range(0, 8):
        if i == a:
            X[i] = 1



def sum(X):
    if (X[1] + X[3] + X[5] + X[7] > 0):
        Y[2] = 1
    if (X[2] + X[3] + X[6] + X[7] > 0):
        Y[1] = 1
    if (X[4] + X[5] + X[6] + X[7] > 0):
        Y[0] = 1

def get_entry():
    value = name.get()

    a = int(value)

    if (a>=0 and a <=7):
        Zn(a)
        sum(X)
        res = tk.Label(win, text = f'{Y}').grid(row = 1, column = 1, stick='w')

    else:
        print('Empty')

def clear_all():
    for i in range(8):
        X[i] = 0;
    for i in range(3):
        Y[i] = 0;
    res = tk.Label(win, text=f'{Y}').grid(row=1, column=1, stick='w')


win = tk.Tk()
win.geometry(f"400x500+100+200")
win.title('Proga')

#canvas = tk.Canvas(win, width = 1000, height = 1000)
#canvas.pack()

#NULL_obj = tk.PhotoImage(file = "E:/OVS_projects/Coder/Visual/Coder_NULL.png")
#canvas.create_image(100, 100, image = NULL_obj)

tk.Label(win, text='Enter value(0-7)'). grid(row=0, column=0, stick='w')
name =tk.Entry(win)
name.grid(row=0, column=1,stick='w')

btn1 = tk.Button(win, text='get', command=get_entry)
btn1.grid(row = 0, column = 2, stick='w')

btn2 = tk.Button(win, text='clear', command=clear_all)
btn2.grid(row = 1, column = 2, stick='w')

res = tk.Label(win, text = f'{Y}').grid(row = 1, column = 1, stick='w')


win.grid_columnconfigure(0, minsize=100)
win.grid_columnconfigure(1, minsize=100)
win.grid_columnconfigure(2, minsize=100)
win.grid_columnconfigure(3, minsize=100)

win.mainloop()